package com.gdtsk.recorder

import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.graphics.Typeface
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Lista simples das gravações feitas pelo GDT SK (Filmes/GDT SK). Toque para assistir. */
class RecordingsActivity : Activity() {

    private val uris = ArrayList<Uri>()
    private lateinit var list: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.applyTheme(this)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val title = TextView(this).apply {
            text = "Gravações"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(24), dp(24), dp(24), dp(12))
        }
        list = ListView(this)
        val empty = TextView(this).apply {
            text = "Nenhuma gravação encontrada.\nElas ficam em Filmes/GDT SK, na galeria."
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(empty)
        }
        list.emptyView = empty
        setContentView(root)
        Insets.apply(root)

        list.setOnItemClickListener { _, _, pos, _ -> play(uris[pos]) }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        uris.clear()
        val labels = ArrayList<String>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
        )
        val (sel, args) = if (Build.VERSION.SDK_INT >= 29)
            "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?" to arrayOf("Movies/GDT SK%")
        else
            @Suppress("DEPRECATION")
            "${MediaStore.Video.Media.DATA} LIKE ?" to arrayOf("%/GDT SK/%")

        try {
            contentResolver.query(collection, projection, sel, args, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                while (c.moveToNext()) {
                    uris.add(ContentUris.withAppendedId(collection, c.getLong(iId)))
                    labels.add("${c.getString(iName)}\n${fmtDuration(c.getLong(iDur))}  ·  ${fmtSize(c.getLong(iSize))}")
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível ler as gravações.", Toast.LENGTH_LONG).show()
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
    }

    private fun play(uri: Uri) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Nenhum app para reproduzir vídeo.", Toast.LENGTH_LONG).show()
        }
    }

    private fun fmtDuration(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.getDefault(), "%d:%02d", s / 60, s % 60)
    }

    private fun fmtSize(bytes: Long): String =
        String.format(Locale.getDefault(), "%.1f MB", bytes / 1048576.0)
}
