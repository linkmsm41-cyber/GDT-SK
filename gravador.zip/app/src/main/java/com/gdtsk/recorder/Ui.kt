package com.gdtsk.recorder

import android.app.Activity
import android.content.Context
import android.content.res.Configuration

/** Tema claro/escuro. Se o usuário nunca escolheu, segue o tema do sistema. */
object Ui {
    private const val PREFS = "gdtsk"
    private const val KEY = "dark"

    fun isDark(ctx: Context): Boolean {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (p.contains(KEY)) return p.getBoolean(KEY, false)
        val night = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return night == Configuration.UI_MODE_NIGHT_YES
    }

    fun setDark(ctx: Context, dark: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, dark).apply()
    }

    /** Chamar logo depois do super.onCreate e antes do setContentView. */
    fun applyTheme(a: Activity) {
        a.setTheme(if (isDark(a)) R.style.AppThemeDark else R.style.AppTheme)
    }
}
